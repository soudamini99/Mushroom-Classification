import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.naive_bayes import BernoulliNB
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix
from sklearn import svm
from sklearn.cluster import KMeans
from sklearn.metrics.cluster import adjusted_rand_score
from sklearn.tree import DecisionTreeClassifier

#Importing the dataset
data = pd.read_csv('mushrooms.csv')
data.head()

#Classifying the dataset into attributes and classes
numeric_labels = preprocessing.LabelEncoder()
for col in data.columns:
    data[col] = numeric_labels.fit_transform(data[col])
Y = data['class'].values

#Splitting the data into Training and Testing datasets
X = data.drop('class',1).values   # the .values makes it return a matrix instead of a df
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, random_state=42)


#implementing Gaissian Naive Bayes classifier
bnb = BernoulliNB()
Y_pred_gnb = bnb.fit(X_train, Y_train).predict(X_test)

#Constructing the Confusion matrix
tn1, fp1, fn1, tp1 = confusion_matrix(Y_test, Y_pred_gnb).ravel()
accuracy1 = (tp1+tn1)/(tp1+tn1+fn1+fp1);
precision1 = tp1/(tp1+fp1);
recall1 = tp1/(tp1+fn1);
fscore1 = 2*precision1*recall1/(precision1+recall1);

#Implementing Support Vector Machine
classifier2 = svm.SVC().fit(X_train, Y_train)
Y_pred_svm = classifier2.predict(X_test)

#Constructing the Confusion matrix
tn2, fp2, fn2, tp2 = confusion_matrix(Y_test, Y_pred_svm).ravel()
accuracy2 = (tp2+tn2)/(tp2+tn2+fn2+fp2);
precision2 = tp2/(tp2+fp2);
recall2 = tp2/(tp2+fn2);
fscore2 = 2*precision2*recall2/(precision2+recall2);

#Implementing K Means
classifier3 = KMeans(n_clusters=2, random_state=0).fit(X)
print(classifier3.labels_[:])
rand=adjusted_rand_score(classifier3.labels_[:], Y)

#Implementing the Decision Trees
classifier4 = DecisionTreeClassifier(criterion='entropy', random_state=100, max_depth = 5, min_samples_leaf = 100)
dtree = classifier4.fit(X_train, Y_train)
Y_pred_dtree = classifier4.predict(X_test)

#Constructing the Confusion matrix
tn4, fp4, fn4, tp4 = confusion_matrix(Y_test, Y_pred_dtree).ravel()
accuracy4 = (tp4+tn4)/(tp4+tn4+fn4+fp4);
precision4 = tp4/(tp4+fp4);
recall4 = tp4/(tp4+fn4);
fscore4 = 2*precision4*recall4/(precision4+recall4);

#Calculating the Mean Absolute Error
l = len(Y_test)

mae1 = ((np.absolute(Y_pred_gnb-Y_test).sum())/l)
mae2 = ((np.absolute(Y_pred_svm-Y_test).sum())/l)
mae4 = ((np.absolute(Y_pred_dtree-Y_test).sum())/l)

#Creating the arrays for Accuracy, Precision, Recall and Fscore
metric1 = np.array([accuracy1, accuracy2, accuracy4])
metric2 = np.array([precision1, precision2, precision4])
metric3 = np.array([recall1,recall2, recall4])
metric4 = np.array([fscore1,fscore2, fscore4])
yaxis = np.array([0, 0.5, 1])
#Plotting the graphs
f, (ax1, ax2, ax3, ax4) = plt.subplots(4, 1, sharex=True, sharey=True)
ax1.scatter(metric1, yaxis, color='r')
ax2.scatter(metric2, yaxis, color='g')
ax3.scatter(metric3, yaxis, color='c')
ax4.scatter(metric4, yaxis, color='b')

plt.xlabel('Metric Values')
plt.ylabel('Range')
plt.legend()
plt.show()